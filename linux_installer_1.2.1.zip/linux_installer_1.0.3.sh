#! /bin/bash

# Script to install linux-pre-edr-agent v1.2.1

#Permission Check

if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Detect Linux Distribution

if [ -f /etc/os-release ]; then
    . /etc/os-release

    echo "Detected OS: $PRETTY_NAME"

    case "$ID" in
        ubuntu|debian|linuxmint|kali|parrot)
            PKG_MANAGER="apt"
            INSTALL_CMD="apt install -y"
            INSTALLER="pre-edr-agent_1.2.1_amd64.deb"
            ;;
        
        amzn)
            if command -v dnf >/dev/null 2>&1; then
                PKG_MANAGER="dnf"
                INSTALL_CMD="dnf install -y"
                INSTALLER="pre-edr-agent-1.2.1-1.x86_64.rpm"
            else
                PKG_MANAGER="yum"
                INSTALL_CMD="yum install -y"
                INSTALLER="pre-edr-agent-1.2.1-1.x86_64.rpm"
            fi
            ;;

        rhel|centos|ol|rocky|almalinux|fedora)
            if command -v dnf >/dev/null 2>&1; then
                PKG_MANAGER="dnf"
                INSTALL_CMD="dnf install -y"
                INSTALLER="pre-edr-agent-1.2.1-1.x86_64.rpm"
            else
                PKG_MANAGER="yum"
                INSTALL_CMD="yum install -y"
                INSTALLER="pre-edr-agent-1.2.1-1.x86_64.rpm"
            fi
            ;;
        *)
            PKG_MANAGER="unknown"
            INSTALL_CMD="unsupported"
            echo "Cannot detect Linux distribution."
    		exit 1
            ;;
    esac

    echo "Package Manager : $PKG_MANAGER" >> installation_logs.txt
    echo "Install Command : $INSTALL_CMD" >> installation_logs.txt

else
    echo "Cannot detect Linux distribution."
    exit 1
fi
echo "[INFO] Detect Linux Distribution - OK" >> installation_logs.txt


# Installing the linux agent

sudo wget https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64 -O /usr/bin/yq >/dev/null 2>&1
sudo chmod +x /usr/bin/yq
sudo $INSTALL_CMD "./$INSTALLER"
echo "[INFO] Installation of the Linux agent - OK" >> installation_logs.txt


# Configuring the Linux agent

sudo systemctl stop pre-edr-agent

read -p "Enter the API Key: " api_key
read -p "Enter PRE Collector IP or Domain: " log_dst
echo -e "Select the type of installation:\n1) Server Installation (Through PRE Collector)\n2) Endpoint Installation (Direct log forwarding)\n0) Exit the Installer"
read installation_type
if [ "$installation_type" = "1" ]; then

	#configuration editing for server
	log_url="https://$log_dst:6517/ingest"
	snap_url="https://$log_dst:6516/ingest"

	sudo yq -i \
".pre_server.ingest_url = \"$log_url\" |
 .endpoint_monitoring.ingest_url = \"$snap_url\" |
 .pre_server.api_key = \"$api_key\" |
 .endpoint_monitoring.api_key = \"$api_key\" |
 .pre_server.verify_ssl = false |
 .endpoint_monitoring.verify_ssl = false" \
/etc/pre-edr-agent/config.yaml

elif [ "$installation_type" = "2" ]; then

	#configuration editing for endpoint
	log_url="https://$log_dst:30998/ingest"
	snap_url="https://$log_dst:30999/ingest"

	sudo yq -i \
".pre_server.ingest_url = \"$log_url\" |
 .endpoint_monitoring.ingest_url = \"$snap_url\" |
 .pre_server.api_key = \"$api_key\" |
 .endpoint_monitoring.api_key = \"$api_key\" |
 .pre_server.verify_ssl = false |
 .endpoint_monitoring.verify_ssl = false" \
/etc/pre-edr-agent/config.yaml

elif [ "$installation_type" = "0" ]; then
	echo "Exiting Installer !"
	exit 1

else 

	exit 2

fi
echo "[INFO] Configuration of the Linux agent - OK" >> installation_logs.txt


# Starting the Linux agent
sudo systemctl enable pre-edr-agent
sudo systemctl start pre-edr-agent
sudo systemctl status pre-edr-agent >> installation_logs.txt
sudo systemctl status pre-edr-agent | grep -E "Active:|Loaded:|\.yaml" 2>&1
echo "[INFO] Started of the Linux agent - OK" >> installation_logs.txt
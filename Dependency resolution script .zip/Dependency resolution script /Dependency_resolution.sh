#!/bin/bash

if [ $EUID -ne 0]; then
        echo "This script must be run as root user" 
        exit 1
fi

ls /usr/local/manageengine/uems_agent/logs/Test_result && rm -r /usr/local/manageengine/uems_agent/logs/Test_result

package_name=containerd.x86_64

mkdir /usr/local/manageengine/uems_agent/logs/Test_result

#Running the dependency resolution command with our -dc repo

yum -C --assumeno --color=never --disableplugin=subscription-manager,search-disabled-repos --disablerepo=* --enablerepo=*-dc install $package_name >>  withdcrepo_install.txt 2>&1

#Running dependency resolution command without our -dc repo 

yum -C --assumeno install $packae_name >> withoutdcrepo_install.txt 2>&1

#Running dependency resolution command with -dc repo without cache

yum --assumeno --color=never --disableplugin=subscription-manager,search-disabled-repos --disablerepo=* --enablerepo=*-dc install $package_name >>  withoutcache_dcrepo_install.txt 2>&1

#Running dependency resolution command without -dc repo without cache

yum --assumeno install $package_name >> withoutC_Cxrepo_install.txt 2>&1

#Running dependency resolution command with update with -dc repos 

yum -C --assumeno --color=never --disableplugin=subscription-manager,search-disabled-repos --disablerepo=* --enablerepo=*-dc update $package_name >>  withdcrepo_update.txt 2>&1

#Running dependency resolution commmand with update without -dc repos 

yum -C --assumeno update $package_name >> withCxrepo_update.txt 2>&1

#Running dependency resolution command with -dc repo with update 

yum --assumeno --color=never --disableplugin=subscription-manager,search-disabled-repos --disablerepo=* --enablerepo=*-dc install $package_name >>  withoutC_DCrepo_update.txt 2>&1

#Running dependency resolution command without -dc repo 

yum --assumeno update $package_name >> withoutC_CXrepo_update.txt 2>&1

#collecting RepoDetails and confs files

echo "****************yum.conf*******************" >> /usr/local/manageengine/uems_agent/logs/Test_result/Reposconf.txt
cat /etc/yum.conf >> /usr/local/manageengine/uems_agent/logs/Test_result/Reposconf.txt

echo "****************dnf.conf*******************" >> /usr/local/manageengine/uems_agent/logs/Test_result/Reposconf.txt
cat /etc/dnf/dnf.conf >> /usr/local/manageengine/uems_agent/logs/Test_result/Reposconf.txt

echo "****************repos.d********************" >> /usr/local/manageengine/uems_agent/logs/Test_result/Reposconf.txt
for file in /etc/yum.repos.d/*; do echo $file; cat $file; echo; done >> /usr/local/manageengine/uems_agent/logs/Test_result/Reposconf.txt

#collecting cache details 

ls -lsRh /var/cache/dnf/ >> dnfcache.txt

ls -lsRh /var/cache/yum/ >> yumcache.txt

mv withdcrepo_install.txt withoutdcrepo_install.txt withoutcache_dcrepo_install.txt withoutC_Cxrepo_install.txt withdcrepo_update.txt withCxrepo_update.txt withoutC_DCrepo_update.txt withoutC_CXrepo_update.txt dnfcache.txt yumcache.txt /usr/local/manageengine/uems_agent/logs/Test_result

zip -r /usr/local/manageengine/uems_agent/logs/Test_result.zip /usr/local/manageengine/uems_agent/logs/Test_result/*
